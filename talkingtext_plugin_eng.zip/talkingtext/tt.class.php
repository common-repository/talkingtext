<?php

$play_text = "play";
$download_text = "download";

define("HOST_ADDR","talkingtext.de");
define("PLAYER_PATH","http://".HOST_ADDR."/player/");
define("STANDARD_MP3","/mp3/standard_male.mp3");

	// Funktion, �ber die das Plugin manuell in Wordpress
	// Templates eingef�gt werden kann
	function talkingtext_show_plugin()
	{
		$mp3 = ""; $mp3_id = "";
		cTTPlugin::get_mp3($mp3,$mp3_id);
		if (strpos(strtolower($mp3),".mp3") !== false)		
		{				
			$talking_text = utf8_encode(cTTPlugin::generate_tt($mp3_id)); 
			$position_mode = get_option("eostt_tt_plugin_position");
			// nur ausgeben, wenn Plugin manuell positioniert wird:
			if ($position_mode == "manu") echo $talking_text;
		}
	}

class cTTPlugin {


	// ===============================================

	function cTTPlugin()
	{
		// nix da			
	}

	// ===============================================

	function init()
	{
		if (get_option(eostt_tt_plugin_position) == "")
			add_option("eostt_tt_plugin_position","auto"); 
	
		if (get_option("eostt_playback_links") == "");
			add_option("eostt_playback_links","both");
			
		if (get_option("eostt_icon_play") == "");
			add_option("eostt_icon_play","1-play.png");
			
		if (get_option("eostt_icon_download") == "");
			add_option("eostt_icon_download","1-down.png");
			
		add_action ('wp_head', 'init_javascript');	 	
		add_action('edit_post','update_database');		
		
		// ===============================================
			
		function init_javascript($content)
		{	
			?>
			<script src="<?php echo get_bloginfo('wpurl'); ?>/wp-content/plugins/talkingtext/pop.js" type="text/javascript"></script>
			<!--[if lt IE 7.]>
			<script defer type="text/javascript" src="<?php echo get_bloginfo('wpurl');?>/wp-content/plugins/talkingtext/transp.js">
			</script>		
			<![endif]-->
			<?php			
		}
		
		// ===============================================
		
		function update_database($post_id)
		{
			$item_id = get_permalink($post_id);
			
			$data = "item_id=$item_id";
			
			$rslt = cTTPlugin::post_to_host(
              					HOST_ADDR,
			              		"/update_feed_item.php",
    			          		$_SERVER['HTTP_REFERER'],
             					$data
							);		
		}
	}


	// ===============================================
	
	function generate_tt($mp3)
	{		
		global $play_text;
		global $download_text;
		
		 //$player_width = 110; $player_height = 34;
	 	$player_width = 196; $player_height = 55;
	 	//$width_offset = 290; $height_offset = 150;
	 	$width_offset = 230; $height_offset = 150;

		if ($mp3 == -1) $mp3="http://".HOST_ADDR.STANDARD_MP3;	
		
		$params = 	"?path=".PLAYER_PATH."&amp;src=$mp3&amp;skin=tt&amp; \
					width=$player_width&amp;height=$player_height \
					&amp;bgcolor=ffffff&amp;down_id=$mp3";

	 	$playback_links = get_option("eostt_playback_links");
	 	
		$width_icon = 30; $height_icon = 20;	
		 		
		$onclick_play = "<a href=\"#\" title='Play mp3' onclick=\"return PopUp('".PLAYER_PATH."player.php$params',$player_width+$width_offset,$player_height+$height_offset);\">";		
		$onclick_download = "<a title='Download mp3' href='$mp3'>";		
		
		// Play Button generieren
		if ($playback_links == "both" || $playback_links == "icons")
			$output.="$onclick_play<img src='".get_bloginfo('wpurl')."/wp-content/plugins/talkingtext/icons/".get_option('eostt_icon_play')."' width='$width_icon' height='$height_icon' border='0' alt='tt_play'/></a>";			
		
		if ($playback_links == "both" || $playback_links == "text")
		{
			if ($playback_links == "text") $caption="Listen to this article:";
				
			$output.="$caption $onclick_play $play_text</a>";	
		}			
	
		// Download Button generieren
		if ($playback_links == "both" || $playback_links == "icons")
			$output.= "$onclick_download<img src='".get_bloginfo('wpurl')."/wp-content/plugins/talkingtext/icons/".get_option('eostt_icon_download')."' width='$width_icon' height='$height_icon' border='0' style='margin-left:10px;' alt='tt_download'/></a>";			
				
		if ($playback_links == "both" || $playback_links == "text")	
			$output.= "$onclick_download $download_text</a>";
	 
		return $output;
	}	

	// ===============================================

	function get_mp3(&$mp3,&$mp3_id)
	{
		$ident_str = get_option("eostt_verified_id");			 			
		$permalink = get_permalink();
		$data = "permalink=$permalink&ident_str=$ident_str";		// &ident_str=
		$rslt = cTTPlugin::post_to_host(
		              					HOST_ADDR,
					              		"/get_mp3.php",
		    			          		$_SERVER['HTTP_REFERER'],
		             					$data
									);
		
		$mp3 = substr($rslt,strpos($rslt,"http://"));
		$mp3_id = substr($rslt,strpos($rslt,"MP3_ITEM="));
		$mp3_id = substr($mp3_id,strpos($mp3_id,"=")+1);
	}

	// ===============================================

	function activate()
	{	
		add_filter('the_content', 'eos_tt_show');
	
		function eos_tt_show($content)
		{								
			$position_mode = get_option("eostt_tt_plugin_position");
			if (get_option("eostt_verified"))
			{
				$mp3 = ""; $mp3_id = "";
			 	cTTPlugin::get_mp3($mp3,$mp3_id);

				if (strpos(strtolower($mp3),".mp3") !== false)		
				{				
				 	// show plugin in blog
					$talking_text = utf8_encode(cTTPlugin::generate_tt($mp3_id)); 
					if ($position_mode == "auto")
						return $content.$talking_text;			
				}
			}		
			return $content;
		}
	}

	// ===============================================

	function post_to_host($host, $path, $referer, $data_to_send) {
	  $fp = fsockopen($host, 80);
	  fputs($fp, "POST $path HTTP/1.1\r\n");
	  fputs($fp, "Host: $host\r\n");
	  fputs($fp, "Referer: $referer\r\n");
	  fputs($fp, "Content-type: application/x-www-form-urlencoded\r\n");
	  fputs($fp, "Content-length: ". strlen($data_to_send) ."\r\n");
	  fputs($fp, "Connection: close\r\n\r\n");
	  fputs($fp, $data_to_send);
	  while(!feof($fp)) {
	      $res .= fgets($fp, 128);
	  }
	  fclose($fp);
	
	  return $res;
	}

	// ===============================================

	function check_id_code($mail,$id_code)
	{
		
		$data = "email=$mail&id_code=$id_code";		
		$rslt = cTTPlugin::post_to_host(
		              					HOST_ADDR,
					              		"/validate.php",
		    			          		$_SERVER['HTTP_REFERER'],
		             					$data
									);		
		return strpos($rslt,"TT_TRUE");	
	}
	
	// ===============================================
	
	function save_state($ident_str)	
	{
		add_option("eostt_verified",true);
		update_option("eostt_verified", true);
		add_option("eostt_verified_id",$ident_str);
		update_option("eostt_verified_id",$ident_str);
		echo "Your blog has been activated sucessfully!";
	}
	
	
	// ===============================================		

	function setup_options_menu()
	{	
		// mt_add_pages() is the sink function for the 'admin_menu' hook
		function mt_add_pages() {
			if (function_exists('add_options_page')) {		
				add_submenu_page("plugins.php", 'Talkingtext', 'Talkingtext', 8, 'testoptions', 'my_options_subpanel');				
			}
		}
	
		// ===============================================
		
		function get_voice()
		{
			$id_code = get_option("eostt_verified_id");
			$data = "id_code=$id_code";
			$rslt = cTTPlugin::post_to_host(
		      					HOST_ADDR,
			              		"/get_voice.php",
				          		$_SERVER['HTTP_REFERER'],
	     						$data
							);
			return substr($rslt,strpos($rslt,"VOICE=")+6);
		}
		
		
		// ===============================================		
	
		function get_icons()
		{			
			$icons = array();
			$cwd = getcwd();
			$cwd = substr($cwd,0,strlen($cwd)-(strlen($cwd)-strrpos($cwd,"/")));			
			$dir = $cwd."/wp-content/plugins/talkingtext/icons/";
			if (is_dir($dir))
			{
				if ($dh = opendir($dir))
				{
					while (($file = readdir($dh)) !== false)
					{
						$path_parts = pathinfo($dir.$file);
						if (
								$path_parts["extension"] == "png" || $path_parts["extension"] == "jpg" ||
								$path_parts["extension"] == "jpeg" || $path_parts["extension"] == "gif"
							)
						{
							$icons[] = $file;	
						}
						 
			        }
					closedir($dh);
				}
			}
			return $icons;
		}
	
		// ===============================================
		
		function set_icons($selected)
		{			
			update_option("eostt_icon_download",$selected);			
			$selected = preg_replace("/down/","play",$selected);			
			update_option("eostt_icon_play",$selected);
		}
		
		// ===============================================
		
		function change_voice($voice)
		{
			$id_code = $_POST['id_code'];
			$data = "voice=$voice&id_code=$id_code";
			$rslt = cTTPlugin::post_to_host(
    	      					HOST_ADDR,
			              		"/change_voice.php",
				          		$_SERVER['HTTP_REFERER'],
         						$data
							);
			?><div class="updated"><p/><strong>Voice changed</strong></div><?php				
		}
		
		// ===============================================
		
		function reset_plugin()
		{
			?><div class="updated"><p/><strong><?php
							
			$data = "id_code=".get_option("eostt_verified_id")."&email=".$_POST['email'];
					
			$rslt = cTTPlugin::post_to_host(
    	      					HOST_ADDR,
			              		"/reset_plugin.php",
				          		$_SERVER['HTTP_REFERER'],
         						$data
							);

			update_option("eostt_verified", false);
			update_option("eostt_verified_id","");
						
			if ( strpos($rslt,"RESULT=ERROR") === false )
			{
				echo "Reset successful!"; // text
			}
			else
			{
				echo "Could not reset. Please check your mail address!"; // text
			}
			
			?></strong></div><?php			
		}
		
		// ===============================================
				
		function activate_plugin()
		{
			?><div class="updated"><p/><strong><?php 
			
			    $verified = get_option("eostt_verified");
				if (!$verified) 
				{
			    	if (cTTPlugin::check_id_code($_POST['email'],$_POST['ident']))
						cTTPlugin::save_state($_POST['ident']);
					else
						echo "Error: Mail address or identification code is wrong!";				
				}
				else
				{
					echo "This blog is already activated";
				}			
			?></strong></p></div><?php			
		}
		// ===============================================
	
		function my_options_subpanel() {
		 	// Plugin automatisch od. manuell im Blog positionieren	
			if (isset($_POST['tt_plugin_position']))
			{
				add_option("eostt_tt_plugin_position","auto"); 
				update_option("eostt_tt_plugin_position", $_POST['tt_plugin_position']);								
			}			
			else
			// Icon Anzeige wechseln
			if (isset($_POST['playback_links']))
			{
				add_option("eostt_playback_links","both");
				update_option("eostt_playback_links", $_POST['playback_links']);				
			}
			else
			// Stimme wechseln
			if (isset($_POST['voice']))
			{
				change_voice($_POST['voice']);
			}
			else
			// Reset des Plugins
			if (isset($_POST['tt_reset']))
			{
				reset_plugin();
			}
			else
			// Icons �ndern
			if (isset($_POST['tt_icon_button']))
			{
				set_icons($_POST['tt_icon_button']);
			}
			else
			// Aktivierung des Plugins
			if (isset($_POST['eostts_activate']))
			{
				activate_plugin();
			}
			?>
		
		
		<!-- ++++++++++++++++++ START: ANGABE DES RSS FEED ++++++++++++++++++ -->

		<?php		
		$feed_url = get_bloginfo('wpurl').'/wp-content/plugins/talkingtext/rss2.php';
		?>
		<div class=wrap>
		<form method="post">
		    <h2>RSS Feed</h2>
		    <fieldset name="set1">
			<legend>
				Please register this rss feed on <a href="http://www.talkingtext.com">www.talkingtext.com</a> under "Talking Blog". <br/>After that you will receive an identification code that you have to enter here to activate your plugin.
			</legend>
			<input name="rss" type="text" size="92" maxlength="100" value="<?php echo $feed_url ?>">
			</fieldset>		
		</form>
		</div>					
		
		<!-- ++++++++++++++++++ ENDE: ANGABE DES RSS FEED ++++++++++++++++++ -->
		
		<!-- ++++++++++++++++++ START: STIMME AUSW�HLEN ++++++++++++++++++ -->
		
		<?php
		if (get_option("eostt_verified"))
		{
		?>	 
		<div class=wrap>
			<form method="post">
		    <h2>Change voice</h2>
		    Here you can change the reader's voice. If you change the voice only new blog entries will be affected!<p/>		    
			<fieldset name="set1">
			<legend>Stimme w&auml;hlen:</legend>
			
				<?php
					$voice = get_voice();
					$voice_phillippe = $voice == "Phillippe" ? "checked=\"checked\"" : "";
					$voice_isabelle = $voice == "Isabelle" ? "checked=\"checked\"" : "";
					$voice_angela = $voice == "Angela" ? "checked=\"checked\"" : "";										
					$voice_george = $voice == "George" ? "checked=\"checked\"" : "";
				?>

				<input type="radio" name="voice" value="Angela (englisch)" <?php echo $voice_angela ?>>Angela (englisch)<br/>
				<input type="radio" name="voice" value="George (englisch)" <?php echo $voice_george ?>>George (englisch)<br/>				
				<input type="radio" name="voice" value="Phillippe (deutsch)" <?php echo $voice_phillippe ?>>Phillippe (deutsch)<br/>
				<input type="radio" name="voice" value="Isabelle (deutsch)" <?php echo $voice_isabelle ?>>Isabelle (deutsch)<br/>							

				<input type="hidden" name="id_code" value="<?php echo get_option('eostt_verified_id') ?>">
			    </fieldset>
				<div class="submit">
				<input type="submit" name="tt_change_voice" value="Save">
				</div>
			  </form>
			 </div>
		<?php
		}
		?>	
		
		<!-- ++++++++++++++++++ ENDE: STIMME AUSW�HLEN ++++++++++++++++++ -->		
		
		<!-- ++++++++++++++++++ START: PLUGIN MANUELL OD. AUTOM. PLAZIEREN ++++++++++++++++++ -->
		
		<?php
		if (get_option("eostt_verified"))
		{
		 	$plugin_position = get_option("eostt_tt_plugin_position") != "" ? get_option("eostt_tt_plugin_position") : "auto";
		 	$checked_auto = $plugin_position == "auto" ? "checked=\"checked\"" : "";
		 	$checked_manu = $plugin_position == "manu" ? "checked=\"checked\"" : "";
		?>	 			 		 	
		<div class=wrap>
		<form method="post">
		<h2>Position your plugin</h2>
		<fieldset name="set1">		
		<legend>
			Here you can define whether you want the plugin to automatically position the play and download buttons<br/> or if you want to position these buttons manually.<p/>To manually position the buttons in your template please use the <span style="font-family: courier,monospace,serif;color:red;">talkingtext_show_plugin();</span> command.
		</legend>	
		<p/><input name="tt_plugin_position" type="radio" value="auto" <?php echo $checked_auto; ?>>Automatically<br/>
		<input name="tt_plugin_position" type="radio" value="manu" <?php echo $checked_manu; ?>>Manually<br/>				
		</fieldset>
		<div class="submit">
			<input type="submit" name="info_update" value="Save">		 
		</div>
		</form>
		</div>
		<?php
		}			
		?>
		
		<!-- ++++++++++++++++++ ENDE: PLUGIN MANUELL OD. AUTOM. PLAZIEREN ++++++++++++++++++ -->		
		
		<!-- ++++++++++++++++++ START: PLAY/DOWNLOAD-Link Konfig ++++++++++++++++++ -->		
		
		<?php
		if (get_option("eostt_verified"))
		{
		 	$playback_links = get_option("eostt_playback_links") != "" ? get_option("eostt_playback_links") : "both";
		 	$checked_both = $playback_links == "both" ? "checked=\"checked\"" : "";
		 	$checked_icons = $playback_links == "icons" ? "checked=\"checked\"" : "";
		 	$checked_text = $playback_links == "text" ? "checked=\"checked\"" : "";
		?>	 			 		 	
			<div class=wrap>
			<form method="post">
			<h2>Button Configuration</h2>
			<fieldset name="set1">
			<legend>Configure the play/download buttons:</legend>
			<input name="playback_links" type="radio" value="both" <?php echo $checked_both ?>>Show icons and textlinks<br/>
			<input name="playback_links" type="radio" value="icons" <?php echo $checked_icons ?>>Show icons only<br/>
			<input name="playback_links" type="radio" value="text" <?php echo $checked_text ?>>Show textlinks only
			</fieldset>
			<div class="submit">
				<input type="submit" name="info_update" value="Save">		 
			</div>
			</form>
			</div>
		<?php
		}
		?>
		
		<!-- ++++++++++++++++++ ENDE: PLAY/DOWNLOAD-Link Konfig ++++++++++++++++++ -->
		
		<!-- ++++++++++++++++++ START: GRAFIKEN F�R ICONS W�HLEN ++++++++++++++++++ -->
		<?php
		if (get_option("eostt_verified"))
		{
			$icons = get_icons();
		?>
			<div class=wrap>
			<h2>Choose icons</h2>
			Select icons for download/play buttons.<p/>
			To use your own icons, please upload your image files to the "icons" subdirectory within the Talkingtext plugin directory. Please name your files according to the following pattern:<p/>1-down.png<br/>1-play.png<p/>...<p/>10-down.jpg<br/>10-play.jpg
			<form method="post">
			<table border="0" width="300" style="border: 1px solid black; border-collapse:collapse;">
			<tr>
				<th style="border: 1px solid black;">Download</th>
				<th style="border: 1px solid black;">Play</th>
				<th></th>
			</tr>
			<?php

			$pic_dir.= "/wordpress/wp-content/plugins/talkingtext/icons/";
			
			for ($i=0; $i<sizeof($icons); $i+=2)
			{		
				$checked = $icons[$i] == get_option("eostt_icon_download") ? "checked=\"checked\"" : "";
				?>
				<tr >
				<td style="border: 1px solid black; padding:1.2%;">
					<img src="<?php echo $pic_dir.$icons[$i];?>" alt="icon" width="30" height="20">
					<?php echo $icons[$i];?>					
				</td>
				<td style="border: 1px solid black; padding:1.2%;">
					<img src="<?php echo $pic_dir.$icons[$i+1];?>" alt="icon" width="30" height="20">
					<?php echo $icons[$i+1];?>
				</td>
				<td style="border: 1px solid black; padding:1.2%;">
					<input type="radio" name="tt_icon_button" value="<?php echo $icons[$i] ?>" <?php echo $checked ?>>
				</td>
				
				</tr>
				<?php
			}
			?>
			</table>
			<br/>
			<div class="submit">
				<input type="submit" name="info_update" value="Save">
			</div>
			</form>
			</div>
			<?php			
		}
		?>
		
		<!-- ++++++++++++++++++ ENDE: GRAFIKEN F�R ICONS W�HLEN ++++++++++++++++++ -->		
		
		<!-- ++++++++++++++++++ START: TALKINGTEXT FREISCHALTUNG ++++++++++++++++++ -->					

		<?php
		if (!get_option("eostt_verified"))
		{
		?>
			<div class=wrap>
				<form method="post">
					<h2>Talkingtext Activation</h2>
					<fieldset name="set1">
					<legend>Talkingtext login mail address:</legend>
					<input name="email" type="text" size="30" maxlength="80" value="">
					</fieldset>
					<fieldset name="set2">
					<legend>Identification code:</legend>
					<input name="ident" type="text" size="30" maxlength="70" value="">
					</fieldset>
					<div class="submit">
					<input type="submit" name="eostts_activate" value="Save">
					</div>
				</form>
			</div>
		<?php
		}
		?>

		<!-- ++++++++++++++++++ ENDE: TALKINGTEXT FREISCHALTUNG ++++++++++++++++++ -->
		
		<!-- ++++++++++++++++++ START: RESET DES PLUGINS ++++++++++++++++++ -->							

		<?php
		if (get_option("eostt_verified"))
		{
		?>
			<div class=wrap>
				<form method="post">
					<h2>Reset</h2>
					Here you can reset your talkingtext plugin. All generated audio content will be deleted. If you want to continue to use the talkingtext plugin after the reset you have to re-enter your blog�s rss url under "Talking Blog" on www.talkingtext.com.<p/>			    
					<fieldset name="set1">
					<legend>Talkingtext login mail address:</legend>
					<input name="email" type="text" size="30" maxlength="80" value="">
				    </fieldset>				
					<div class="submit">
					<input type="submit" name="tt_reset" value="Reset">
					</div>
				</form>
			</div>
		<?php
		}
		?>
		
		<!-- ++++++++++++++++++ ENDE: RESET DES PLUGINS ++++++++++++++++++ -->							
		
		<?php
		}
		// Insert the mt_add_pages() sink into the plugin hook list for 'admin_menu'
		add_action('admin_menu', 'mt_add_pages');
	}	
}

?>
