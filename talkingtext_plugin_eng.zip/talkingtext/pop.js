function PopUp(popurl,width,height)
{
	var URL = popurl;
	var Name = "TalkingtextPlayer";
	var Fensteroptionen = "toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=0";
	var Breite = width;
	var Hoehe = height;
	
	var winbreite = (screen.width - Breite) / 2;
	var winhoehe = (screen.height - Hoehe) / 2;	
	window.open(URL, 'Name', Fensteroptionen + ',width=' + Breite + ',height=' + Hoehe + ',top=' + winhoehe + ',left=' + winbreite);
}