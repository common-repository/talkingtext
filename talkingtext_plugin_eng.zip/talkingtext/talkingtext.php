<?php
	/*
		Plugin Name: Talkingtext
		Version: 0.95
		Plugin URI: http://www.talkingtext.com		
		Description: Free plugin to convert blog entries to speech (text-to-speech technology). Blog entries will be converted into audio files. A flash player to playback audio files is provided. Information on how to activate your plugin can be found here: <a href="http://www.talkingtext.com">talkingtext.com</a>.		
		Author: Nils Herzog
		Author URI: http://www.talkingtext.com
	*/

	require_once('tt.class.php');
	$talkingtext_plugin = new cTTPlugin();

	$talkingtext_plugin->setup_options_menu();
	$talkingtext_plugin->init();
	$talkingtext_plugin->activate();

?>
